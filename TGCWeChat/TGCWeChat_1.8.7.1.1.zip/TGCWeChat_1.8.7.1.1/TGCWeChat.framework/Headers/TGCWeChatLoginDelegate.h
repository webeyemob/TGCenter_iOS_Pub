//
//  TGCWeChatLoginDelegate.h
//  TGCenter
//
//  Created by TGCenter on 2021/3/4.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#ifndef TGCWeChatLoginDelegate_h
#define TGCWeChatLoginDelegate_h

@protocol TGCWeChatLoginDelegate <NSObject>

@optional
- (void)tgcWeChatLogin_Success:(NSString *)code;

@optional
- (void)tgcWeChatLogin_Fail:(NSString *)msg;

@optional
- (void)tgcWeChatLogin_Cancel:(NSString *)msg;

@end

#endif /* TGCWeChatLoginDelegate_h */
