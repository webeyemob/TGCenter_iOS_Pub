//
//  TGCWeChatHelper.h
//  TGCWeChat
//
//  Created by TGCenter on 2021/3/4.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <TGCenter/TGCenter.h>
#import "TGCWeChatLoginDelegate.h"
#import "TGCWeChatTypes.h"

NS_ASSUME_NONNULL_BEGIN

@interface TGCWeChatHelper : NSObject

@property (nonatomic, weak) id<TGCWeChatLoginDelegate> loginDelegate;

+ (void)initWithConfig:(TGCInitConfig *)config;

+ (TGCWeChatHelper *)sharedInstance;

- (BOOL)handleOpenURL:(NSURL *)url;

- (void)login:(UIViewController *)viewController;

// Unity
@property (nonatomic,assign) TGCTypeWeChatHelperClientRef weChatHelperClientRef;
@property (nonatomic, assign) TGCWeChatLoginSuccessCallback weChatLoginSuccessCallback;
@property (nonatomic, assign) TGCWeChatLoginFailedCallback weChatLoginFailedCallback;
@property (nonatomic, assign) TGCWeChatLoginCancelCallback weChatLoginCancelCallback;

@end

NS_ASSUME_NONNULL_END
