//
//  TGCWeChat.h
//  TGCWeChat
//
//  Created by TGCenter on 2021/3/4.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TGCWeChat.
FOUNDATION_EXPORT double TGCWeChatVersionNumber;

//! Project version string for TGCWeChat.
FOUNDATION_EXPORT const unsigned char TGCWeChatVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TGCWeChat/PublicHeader.h>


#import <TGCWeChat/TGCWeChatHelper.h>
#import <TGCWeChat/TGCWeChatLoginDelegate.h>
