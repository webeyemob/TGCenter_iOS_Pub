//
//  TGCWeChatHelper.h
//  TGCWeChat
//
//  Created by TGCenter on 2021/3/4.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <TGCenter/TGCenter.h>
#import "TGCWeChatLoginDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface TGCWeChatHelper : NSObject

@property (nonatomic, weak) id<TGCWeChatLoginDelegate> loginDelegate;

+ (void)initWithConfig:(TGCInitConfig *)config;

+ (TGCWeChatHelper *)sharedInstance;

- (BOOL)handleOpenURL:(NSURL *)url;

- (void)login:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
