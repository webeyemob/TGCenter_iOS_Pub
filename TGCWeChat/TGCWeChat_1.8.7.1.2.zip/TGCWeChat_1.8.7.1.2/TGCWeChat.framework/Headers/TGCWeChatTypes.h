//
//  TGCWeChatTypes.h
//  TGCWeChat
//
//  Created by TGCenter on 2021/3/16.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#ifndef TGCWeChatTypes_h
#define TGCWeChatTypes_h

typedef const void *TGCTypeWeChatHelperClientRef;

typedef void (*TGCWeChatLoginSuccessCallback)(TGCTypeWeChatHelperClientRef clientRef, char *code);
typedef void (*TGCWeChatLoginFailedCallback)(TGCTypeWeChatHelperClientRef clientRef, char *result);
typedef void (*TGCWeChatLoginCancelCallback)(TGCTypeWeChatHelperClientRef clientRef, char *result);

#endif /* TGCWeChatTypes_h */
