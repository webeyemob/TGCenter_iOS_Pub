//
//  PrivacyPolicyManager.h
//  PrivacyPolicy
//
//  Created by TGCenter on 2021/7/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PrivacyPolicyManager : NSObject

+ (void)init:(NSString *)appId;

+ (NSString *)getAppId;

/*!
@method getSdkVersion
@abstract 获取SDK version
@return  SDK version string
*/
+ (NSString *)getSdkVersion;

@end

NS_ASSUME_NONNULL_END
