//
//  BasePrivacyDialog.h
//  privacypolicy
//
//  Created by TGCenter on 2021/1/13.
//



#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^PPButtonBlock)(void);

@interface BasePrivacyDialog : UIView

-(NSString *)getTitle;

-(NSString *)getDisagreeText;

-(NSString *)getAgreeText;

-(UITextView *)getCustomContentViewWith:(UIColor *)linkTextColor textSize:(CGFloat)textFontSize textColor:(UIColor *)textColor;

-(UITextView *)getDefaultContentTextView;

@end

NS_ASSUME_NONNULL_END
