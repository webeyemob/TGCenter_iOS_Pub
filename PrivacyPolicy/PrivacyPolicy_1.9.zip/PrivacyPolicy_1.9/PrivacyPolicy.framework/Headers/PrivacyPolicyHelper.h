//
//  PrivacyPolicyHelper.h
//  privacypolicy
//
//  Created by TGCenter on 2021/1/12.
//

#import <Foundation/Foundation.h>
#import "PrivacyPolicyDialog.h"

NS_ASSUME_NONNULL_BEGIN

@interface PrivacyPolicyHelper : NSObject

-(void)showDialogWithAgreeBlock:(PPButtonBlock)agreeBlock andDisagreeBlock:(PPButtonBlock)disagreeBlock inParentView:(UIView *)parentView;

-(void)jumpToUserAgreement;

-(void)jumpToPrivacyPolicy;


@end

NS_ASSUME_NONNULL_END
