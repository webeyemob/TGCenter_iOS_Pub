//
//  PrivacyPolicy.h
//  PrivacyPolicy
//
//  Created by TGCenter on 2021/6/3.
//

#import <Foundation/Foundation.h>

//! Project version number for PrivacyPolicy.
FOUNDATION_EXPORT double PrivacyPolicyVersionNumber;

//! Project version string for PrivacyPolicy.
FOUNDATION_EXPORT const unsigned char PrivacyPolicyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PrivacyPolicy/PublicHeader.h>

#import <PrivacyPolicy/PrivacyPolicyManager.h>
#import <PrivacyPolicy/BasePrivacyDialog.h>
#import <PrivacyPolicy/PrivacyPolicyHelper.h>
#import <PrivacyPolicy/PrivacyPolicyDialog.h>
