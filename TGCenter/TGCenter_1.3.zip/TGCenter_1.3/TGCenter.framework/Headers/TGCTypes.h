//
//  TGCTypes.h
//  TGCenter
//
//  Created by TGCenter on 2021/1/29.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#ifndef TGCTypes_h
#define TGCTypes_h

typedef const void *TGCTypeRef;

#pragma mark - TGCenterSdk
typedef const void *TGCTypeInitConfigRef;
typedef const void *TGCTypeDay1RetentionRef;

#endif /* TGCTypes_h */
