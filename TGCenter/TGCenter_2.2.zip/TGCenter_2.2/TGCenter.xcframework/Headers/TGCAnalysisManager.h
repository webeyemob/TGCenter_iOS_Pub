//
//  TGCAnalysisManager.h
//  TGCenter
//
//  Created by TGCenter on 2021/7/28.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TGCAnalysisConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface TGCAnalysisManager : NSObject

+ (TGCAnalysisManager *)sharedInstance;

- (void)start:(TGCAnalysisConfig *)config;

@end

NS_ASSUME_NONNULL_END
