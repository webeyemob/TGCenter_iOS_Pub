//
//  TGCenterSdk.h
//  TGCenter
//
//  Created by TGCenter on 2021/1/11.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TGCInitConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface TGCenterSdk : NSObject

+ (TGCenterSdk *)sharedInstance;

+ (NSString *)getSdkVersion;
+ (NSString *)parseVersionFromVersionString:(char *)versionString;

- (void)initWithConfig:(TGCInitConfig *)config;

- (TGCInitConfig *)getInitConfig;

- (BOOL)isUserAgreePolicy;

/**
* 当在开发者后台配置次留上报逻辑为 Other 时，App 可以自己发送 w_retention 事件。
* 调用此 API 可以发送次留事件，并且会记录事件的发送状态，避免发送多次。
*/
- (void)reportCustomRetention;

- (void)clearCache;

@end

NS_ASSUME_NONNULL_END
