//
//  TGCInitConfig.h
//  TGCenter
//
//  Created by TGCenter on 2021/1/11.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGCInitConfig : NSObject

@property BOOL debugMode;
@property (nonatomic, strong) NSString *appId;

@property (nonatomic, strong) NSString *appleAppID;

@property (nonatomic, strong) NSString *umengAppKey;

@property (nonatomic, strong) NSString *appsFlyerDevKey;

@property (nonatomic, strong) NSString *rangersAppLogAppId;
@property (nonatomic, strong) NSString *rangersAppLogAppName;

@property (nonatomic, strong) NSString *weChatAppId;
@property (nonatomic, strong) NSString *weChatUniversalLink;

@property (nonatomic, strong) NSString *udeskDomain;
@property (nonatomic, strong) NSString *udeskAppKey;
@property (nonatomic, strong) NSString *udeskAppId;

// 下面的参数不需要 App 配置
@property int retentionType;
@property int retentionNum;

@end

NS_ASSUME_NONNULL_END
