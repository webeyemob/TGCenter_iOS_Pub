//
//  UdeskAlbumCell.h
//  UdeskImagePickerController
//
//  Created by xuchen on 2018/3/6.
//  Copyright © 2018年 Udesk. All rights reserved.
//

#import <UIKit/UIKit.h>
@class UdeskAlbumModel;

@interface UdeskAlbumCell : UITableViewCell

@property (nonatomic, strong) UdeskAlbumModel *albumModel;

@end
