//
//  UdeskAssetsPickerController.h
//  UdeskImagePickerController
//
//  Created by xuchen on 2018/3/6.
//  Copyright © 2018年 Udesk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UdeskAssetsPickerController : UIViewController

@property (nonatomic, assign) NSInteger albumIndex;

@end
