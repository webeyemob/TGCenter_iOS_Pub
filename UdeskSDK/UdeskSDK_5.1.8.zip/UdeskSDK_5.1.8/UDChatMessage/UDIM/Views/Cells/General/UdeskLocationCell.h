//
//  UdeskLocationCell.h
//  UdeskSDK
//
//  Created by xuchen on 2017/8/16.
//  Copyright © 2017年 Udesk. All rights reserved.
//

#import "UdeskBaseCell.h"

@interface UdeskLocationCell : UdeskBaseCell

@end
