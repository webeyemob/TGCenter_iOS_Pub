//
//  UdeskVoiceCell.h
//  UdeskSDK
//
//  Created by xuchen on 2017/5/17.
//  Copyright © 2017年 Udesk. All rights reserved.
//

#import "UdeskBaseCell.h"

@interface UdeskVoiceCell : UdeskBaseCell

@end
