//
//  UdeskTemplateCell.h
//  UdeskSDK
//
//  Created by xuchen on 2019/6/5.
//  Copyright © 2019 Udesk. All rights reserved.
//

#import "UdeskBaseCell.h"

@interface UdeskTemplateCell : UdeskBaseCell

@end
