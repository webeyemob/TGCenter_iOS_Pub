//
//  UdeskGoodsCell.h
//  UdeskSDK
//
//  Created by xuchen on 2018/6/23.
//  Copyright © 2018年 Udesk. All rights reserved.
//

#import "UdeskBaseCell.h"

@interface UdeskGoodsCell : UdeskBaseCell

@end
