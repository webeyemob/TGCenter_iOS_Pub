//
//  UdeskTopAskCell.h
//  UdeskSDK
//
//  Created by xuchen on 2019/1/21.
//  Copyright © 2019 Udesk. All rights reserved.
//

#import "UdeskBaseCell.h"

@interface UdeskTopAskCell : UdeskBaseCell

@end
