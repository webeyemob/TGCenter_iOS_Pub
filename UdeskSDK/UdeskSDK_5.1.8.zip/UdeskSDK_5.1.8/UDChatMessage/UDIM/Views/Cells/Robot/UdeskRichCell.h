//
//  UdeskRichCell.h
//  UdeskSDK
//
//  Created by xuchen on 2019/1/16.
//  Copyright © 2019 Udesk. All rights reserved.
//

#import "UdeskBaseCell.h"

@interface UdeskRichCell : UdeskBaseCell

@end
