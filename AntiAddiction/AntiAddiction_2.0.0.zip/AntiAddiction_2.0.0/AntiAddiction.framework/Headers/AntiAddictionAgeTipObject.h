//
//  AntiAddictionAgeTipObject.h
//  AntiAddiction
//
//  Created by TGCenter on 2021/6/10.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AntiAddictionAgeTipObject : NSObject

@property (nonatomic, strong) NSData   *iconData;         //图标的资源
@property (nonatomic, strong) NSString *ageTipContent;    //适龄提示内容

@property (nonatomic, strong) NSString *healthGameAdviceContent;    //健康游戏开屏显示内容
@property (nonatomic, strong) NSString *healthGameAdviceAppInfo;    //健康游戏开屏应用信息

@end

NS_ASSUME_NONNULL_END
