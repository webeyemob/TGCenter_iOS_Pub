//
//  AntiAddictionObjectCache.h
//  AntiAddiction
//
//  Created by TGCenter on 2021/4/7.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AntiAddictionObjectCache : NSObject

+ (instancetype)sharedInstance;
@property(nonatomic, strong) NSMutableDictionary *references;

@end

// 返回用于查找 Unity 对象的 key。
@interface NSObject (AntiAddictionOwnershipAdditions)

- (NSString *)antiAddiction_referenceKey;

@end

NS_ASSUME_NONNULL_END
