//
//  AntiAddictionTimeLimitEvent.h
//  AntiAddiction
//
//  Created by tgcenter on 2021/5/6.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AntiAddictionTimeLimit.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(int, ANTIADDICTION_TIMELIMIT_EVENT_ACTION) {
    ANTIADDICTION_TIMELIMIT_EVENT_ACTION_UNKNOWN             = -1,
    ANTIADDICTION_TIMELIMIT_EVENT_ACTION_SHOW                = 0,  // 展示时间限制页面
    ANTIADDICTION_TIMELIMIT_EVENT_ACTION_OPENREALNAME        = 1,  // 打开实名认证页面
    ANTIADDICTION_TIMELIMIT_EVENT_ACTION_CLOSEDIALOG         = 2,  // 关闭时间限制弹窗
    ANTIADDICTION_TIMELIMIT_EVENT_ACTION_EXITAPP             = 3   // 退出 App
};

@interface AntiAddictionTimeLimitEvent : NSObject

@property (nonatomic, readonly) ANTIADDICTION_TIMELIMIT_EVENT_ACTION action;   //用户行为
@property (nonatomic, readonly, strong) AntiAddictionTimeLimit *timeLimit;     // 时间限制内容

- (instancetype)initWithAction:(ANTIADDICTION_TIMELIMIT_EVENT_ACTION)action timeLimit:(AntiAddictionTimeLimit *)timeLimit;

@end

NS_ASSUME_NONNULL_END
