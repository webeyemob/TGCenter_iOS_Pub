//
//  AntiAddictionAgeTipDelegate.h
//  AntiAddiction
//
//  Created by tgcenter on 2021/6/9.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#ifndef AntiAddictionAgeTipDelegate_h
#define AntiAddictionAgeTipDelegate_h



typedef NS_ENUM(int, ANTIADDICTION_AGETIP_ERROR_CODE) {
    ANTIADDICTION_AGETIP_ERROR_CODE_UNKNOWN         = -1,
    ANTIADDICTION_AGETIP_ERROR_CODE_CONFIG_ERROR    = -2,
    ANTIADDICTION_AGETIP_ERROR_CODE_NETWORK_ERROR   = -3
};


@protocol AntiAddictionHealthGameAdviceDelegate<NSObject>

/*!
@brief Notified age tip splash has show.
@param none
*/
@optional
- (void)onSplashShown;

/*!
@brief Notified age tip splash show. failed
@param error error info
*/
@optional
- (void)splashShowFailed:(NSError *)error;

/*!
@brief Notified age tip splash has closed.
@param none
*/
@optional
- (void)onSplashClosed;


@end

@protocol AntiAddictionAgeTipIconDelegate <NSObject>

/*!
@brief Notified age tip icon has show.
@param none
*/
@optional
- (void)onIconShown;

/*!
@brief Notified age tip icon show. failed
@param error error info
*/
@optional
- (void)iconShowFailed:(NSError *)error;

/*!
@brief Notified age tip icon has clicked.
@param none
*/
@optional
- (void)onIconClick;

/*!
@brief Notified age tip dialog has show
@param none
*/
@optional
- (void)dialogShown;

/*!
@brief Notified age tip dialog has closed.
@param none
*/
@optional
- (void)dialogClosed;

@end


#endif /* AntiAddictionAgeTipDelegate_h */
