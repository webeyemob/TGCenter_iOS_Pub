//
//  AntiAddictionUser.h
//  AntiAddiction
//
//  Created by zena.tang on 2021/3/18.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AntiAddictionRealNameResult.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(int, ANTIADDICTION_USER_TYPE) {
    ANTIADDICTION_USER_TYPE_TOURIST                        = 0,  //游客
    ANTIADDICTION_USER_TYPE_CHILD                          = 1,  //未成年人
    ANTIADDICTION_USER_TYPE_ADULT                          = 2   //成年人
};

@interface AntiAddictionUser : NSObject


@property (nonatomic, strong) AntiAddictionRealNameResult *realNameResult;

- (int) getAge;

- (BOOL) isTourist;
- (BOOL) isChild;
- (BOOL) isAdult;

@end

NS_ASSUME_NONNULL_END
