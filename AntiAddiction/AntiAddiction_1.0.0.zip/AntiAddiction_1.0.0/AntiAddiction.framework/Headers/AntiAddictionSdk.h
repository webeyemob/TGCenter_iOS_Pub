//
//  AntiAddictionSdk.h
//  AntiAddiction
//
//  Created by zena.tang on 2021/3/18.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AntiAddictionUser.h"
#import "AntiAddictionRealNameDelegate.h"
#import "AntiAddictionTimeLimitDelegate.h"

NS_ASSUME_NONNULL_BEGIN


@interface AntiAddictionSdk : NSObject

+ (void) init: (NSString *)appId;
+ (void) setDebugMode:(BOOL)debugMode;
+ (BOOL) isDebugMode;

+ (NSString *)getAppId;
+ (int)getSdkVersion;

+ (void) setAutoShowTimeLimitPage:(BOOL)autoShow;
+ (BOOL) isAutoShowTimeLimitPage;

+ (AntiAddictionUser *)getUser;

+ (void)realName:(id<AntiAddictionRealNameDelegate>)delegate;

+ (void)realName:(NSString *)name idNumber:(NSString *)idNumber delegate:(id<AntiAddictionRealNameDelegate>)delegate;

+ (void)registerTimeLimitDelegate:(id<AntiAddictionTimeLimitDelegate>)delegate;
+ (void)unRegisterTimeLimitDelegate:(id<AntiAddictionTimeLimitDelegate>)delegate;

+ (void)logOut;

@end

NS_ASSUME_NONNULL_END
