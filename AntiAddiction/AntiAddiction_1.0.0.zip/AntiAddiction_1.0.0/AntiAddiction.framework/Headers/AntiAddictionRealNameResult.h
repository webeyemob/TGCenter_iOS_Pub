//
//  AntiAddictionRealNameResult.h
//  AntiAddiction
//
//  Created by zena.tang on 2021/3/18.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(int, ANTIADDICTION_REALNAME_RESULT_CODE) {
    // ## 系统异常 ##

    // 请求成功
    AntiAddiction_RealName_Result_Success = 0,
    // 系统错误
    AntiAddiction_RealName_Result_Sys_Error = 1001,
    // 接口请求的资源不存在
    AntiAddiction_RealName_Result_Sys_Req_Resource_Not_Exist = 1002,
    // 接口请求方式错误
    AntiAddiction_RealName_Result_Sys_Req_Method_Error = 1003,
    // 接口请求核心参数缺失
    AntiAddiction_RealName_Result_Sys_Req_Header_Miss_Error = 1004,
    // 接口请求IP地址非法
    AntiAddiction_RealName_Result_Sys_Req_Ip_Error = 1005,
    // 接口请求超出流量限制
    AntiAddiction_RealName_Result_Sys_Req_Busy_Error = 1006,
    // 接口请求过期
    AntiAddiction_RealName_Result_Sys_Req_Expire_Error = 1007,
    // 接口请求方身份非法
    AntiAddiction_RealName_Result_Sys_Req_Partner_Error = 1008,
    // 接口请求方权限未启用
    AntiAddiction_RealName_Result_Sys_Req_Partner_Auth_Disable = 1009,
    // 接口请求方无该接口权限
    AntiAddiction_RealName_Result_Sys_Req_Auth_Error = 1010,
    // 接口请求方身份核验错误
    AntiAddiction_RealName_Result_Sys_Req_Partner_Auth_Error = 1011,
    // 接口请求报文核验失败
    AntiAddiction_RealName_Result_Sys_Req_Param_Check_Error = 1012,


    // ## 接口测试业务异常 ##

    // 测试系统错误
    AntiAddiction_RealName_Result_Test_Sys_Error = 4001,
    // 测试任务不存在
    AntiAddiction_RealName_Result_Test_Task_Not_Exist = 4002,
    // 测试参数无效
    AntiAddiction_RealName_Result_Test_Param_Invalid_Error = 4003,


    // ## 实名认证业务异常 ##

    // 身份证号格式校验失败
    AntiAddiction_RealName_Result_Bus_Auth_IdNum_Illegal = 2001,
    // 实名认证条目已达上限
    AntiAddiction_RealName_Result_Bus_Auth_Resource_Limit = 2002,
    // 无该编码提交的实名认证记录
    AntiAddiction_RealName_Result_Bus_Auth_Code_No_Auth_Recode = 2003,
    // 编码已经被占用【在认证中】
    AntiAddiction_RealName_Result_Bus_Auth_Code_Already_In_Use = 2004,


    // ## 游戏用户行为数据上报业务异常 ##

    // 行为数据部分上报失败
    AntiAddiction_RealName_Result_Bus_Coll_Partial_Error = 3001,
    // 行为数据为空
    AntiAddiction_RealName_Result_Bus_Coll_Behavior_Null_Error = 3002,
    // 行为数据超出条目数量限制
    AntiAddiction_RealName_Result_Bus_Coll_Limit_Count = 3003,
    // 行为数据编码错误
    AntiAddiction_RealName_Result_Bus_Coll_No_Invalid = 3004,
    // 行为发生时间错误
    AntiAddiction_RealName_Result_Bus_Coll_Behavior_Time_Error = 3005,
    // BUS COLL PLAYER MODE INVALID
    AntiAddiction_RealName_Result_Bus_Coll_Player_Mode_Invalid = 3006,
    // 行为类型无效
    AntiAddiction_RealName_Result_Bus_Coll_Behavior_Mode_Invalid = 3007,
    // 缺失PI（用户唯一标识）值
    AntiAddiction_RealName_Result_Bus_Coll_PlayerId_Miss = 3008,
    // 缺失DI（设备标识）值
    AntiAddiction_RealName_Result_Bus_Coll_DeviceId_Miss = 3009,
    // PI（用户唯一标识）值无效
    AntiAddiction_RealName_Result_Bus_Coll_PlayerId_Invalid = 3010,
};


@interface AntiAddictionRealNameResult : NSObject


- (BOOL) isInitial;
- (BOOL) isSuccess;
- (BOOL) isProcessing;
- (BOOL) isFail;

- (int)getStatus;
- (int)getResultCode;
- (NSString *)getResultMsg;
- (NSString *)getPlayerId;

- (NSString *) toCache;
+ (AntiAddictionRealNameResult *) fromCache: (NSString *)cache;

+ (AntiAddictionRealNameResult *) fromServer: (NSString *)server;

@end

NS_ASSUME_NONNULL_END
