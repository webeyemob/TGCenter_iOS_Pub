//
//  AntiAddictionTimeLimit.h
//  AntiAddiction
//
//  Created by zena.tang on 2021/3/19.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(int, ANTIADDICTION_TIMELIMIT_REASON) {
    ANTIADDICTION_TIMELIMIT_NO_LIMIT                        = 0,  //没有限制
    
    // 游客限制原因
    ANTIADDICTION_TIMELIMIT_TOURIST_1_HOUR                  = 1,  // 不超过 1 小时体验模式
    
    // 未成年人限制原因
    ANTIADDICTION_TIMELIMIT_CHILD_8H_22H                    = 2,  // 每日 22 时到次日 8 时
    ANTIADDICTION_TIMELIMIT_CHILD_HOLIDAY_3_HOUR            = 3,  // 法定节假日每日游戏时长超过 3 小时
    ANTIADDICTION_TIMELIMIT_CHILD_NORMAL_90_MIN             = 4,  // 其他时间每日游戏时长超过 1.5 小时
};

@interface AntiAddictionLimitTip : NSObject

@property (nonatomic, strong, readonly) NSString *title;
@property (nonatomic, strong, readonly) NSString *desc;
@property (nonatomic, strong, readonly) NSString *button;
@property (nonatomic, readonly) BOOL canRealName;

- (instancetype)initWithTitle:(NSString *)title desc:(NSString *)desc button:(NSString *)button canRealName:(BOOL)canRealName;

@end

@interface AntiAddictionTimeLimit : NSObject
// 限制的原因
@property (nonatomic, readonly) ANTIADDICTION_TIMELIMIT_REASON reason;
// 距离限制的时间
// 限制时间小于一定数值时，需要提示用户
// 0 表示达到限制条件了
@property (nonatomic, readonly) long timeToLimit;
// 需要提示给用户的内容
@property (nonatomic, strong, readonly) AntiAddictionLimitTip *limitTip;

- (instancetype)initWithReason:(ANTIADDICTION_TIMELIMIT_REASON)reason;
- (instancetype)initWithReason:(ANTIADDICTION_TIMELIMIT_REASON)reason timeToLimit:(long)timeToLimit;

- (BOOL)isLimit;


@end

NS_ASSUME_NONNULL_END
