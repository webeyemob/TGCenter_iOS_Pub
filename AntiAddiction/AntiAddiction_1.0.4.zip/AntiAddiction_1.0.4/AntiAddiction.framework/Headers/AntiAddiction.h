//
//  AntiAddiction.h
//  AntiAddiction
//
//  Created by zena.tang on 2021/3/18.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AntiAddiction.
FOUNDATION_EXPORT double AntiAddictionVersionNumber;

//! Project version string for AntiAddiction.
FOUNDATION_EXPORT const unsigned char AntiAddictionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AntiAddiction/PublicHeader.h>

#import <AntiAddiction/AntiAddictionRealNameResult.h>
#import <AntiAddiction/AntiAddictionUser.h>
#import <AntiAddiction/AntiAddictionTimeLimit.h>
#import <AntiAddiction/AntiAddictionRealNameDelegate.h>
#import <AntiAddiction/AntiAddictionTimeLimitDelegate.h>
#import <AntiAddiction/AntiAddictionSdk.h>

#import <AntiAddiction/AntiAddictionUnity.h>
#import <AntiAddiction/AntiAddictionTypes.h>
#import <AntiAddiction/AntiAddictionObjectCache.h>
#import <AntiAddiction/AntiAddictionPluginUtil.h>
