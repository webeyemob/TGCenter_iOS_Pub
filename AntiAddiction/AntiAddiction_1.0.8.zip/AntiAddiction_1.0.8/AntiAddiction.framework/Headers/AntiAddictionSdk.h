//
//  AntiAddictionSdk.h
//  AntiAddiction
//
//  Created by tgcenter on 2021/3/18.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AntiAddictionUser.h"
#import "AntiAddictionRealNameDelegate.h"
#import "AntiAddictionTimeLimitDelegate.h"

NS_ASSUME_NONNULL_BEGIN


@interface AntiAddictionSdk : NSObject

+ (void) init: (NSString *)appId;
+ (void) setDebugMode:(BOOL)debugMode;
+ (BOOL) isDebugMode;

+ (NSString *)getAppId;
+ (NSString *)getSdkVersion;
+ (int)getSdkVersionCode;

+ (void) setAutoShowTimeLimitPage:(BOOL)autoShow;
+ (BOOL) isAutoShowTimeLimitPage;

+ (AntiAddictionUser *)getUser;

// 实名认证，使用 SDK 默认的弹窗
+ (void)realName:(id<AntiAddictionRealNameDelegate>)delegate;

// 实名认证，使用 SDK 默认的弹窗
// source 表示实名认证的来源，可以参考 ANTIADDICTION_REALNAME_EVENT_SOURCE
// 也可以自定义 int 数值，表示不同的页面
+ (void)realName:(int)source delegate:(id<AntiAddictionRealNameDelegate>)delegate;

// 实名认证，使用 App 的弹窗
+ (void)realName:(NSString *)name idNumber:(NSString *)idNumber delegate:(id<AntiAddictionRealNameDelegate>)delegate;

// 实名认证，使用 App 的弹窗
// source 表示实名认证的来源，可以参考 ANTIADDICTION_REALNAME_EVENT_SOURCE
// 也可以自定义 int 数值，表示不同的页面
+ (void)realName:(int)source name:(NSString *)name idNumber:(NSString *)idNumber delegate:(id<AntiAddictionRealNameDelegate>)delegate;

+ (void)registerTimeLimitDelegate:(id<AntiAddictionTimeLimitDelegate>)delegate;
+ (void)unRegisterTimeLimitDelegate:(id<AntiAddictionTimeLimitDelegate>)delegate;

+ (void)logOut;

@end

NS_ASSUME_NONNULL_END
