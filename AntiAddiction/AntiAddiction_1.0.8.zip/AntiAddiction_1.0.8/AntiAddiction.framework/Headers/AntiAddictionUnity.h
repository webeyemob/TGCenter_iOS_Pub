//
//  AntiAddictionUnity.h
//  AntiAddiction
//
//  Created by TGCenter on 2021/4/7.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AntiAddictionTypes.h"
#import "AntiAddictionUser.h"

NS_ASSUME_NONNULL_BEGIN

@interface AntiAddictionUnity : NSObject

+ (AntiAddictionUnity *)sharedInstance;

- (void)setAntiAddictionClient:(AntiAddictionTypeAntiAddictionClientRef _Nullable* _Nullable)client;

- (void)realName:(AntiAddictionRealNameCallback)callback;

- (void)realName:(NSString *)name
        idNumber:(NSString *)idNumber
        callback:(AntiAddictionRealNameCallback)callback;

- (void)setTimeLimitCallback:(AntiAddictionTimeLimitCallback)callback;

+ (AntiAddictionTypeUserRef)AntiAddictionCreateUser:(AntiAddictionUser *)user;

@end

NS_ASSUME_NONNULL_END
