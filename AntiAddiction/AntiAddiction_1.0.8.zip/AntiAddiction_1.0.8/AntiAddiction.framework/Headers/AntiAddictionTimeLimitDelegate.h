//
//  AntiAddictionTimeLimitDelegate.h
//  AntiAddictionDemo
//
//  Created by tgcenter on 2021/3/19.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#ifndef AntiAddictionTimeLimitDelegate_h
#define AntiAddictionTimeLimitDelegate_h

#import "AntiAddictionTimeLimit.h"


@protocol AntiAddictionTimeLimitDelegate<NSObject>

/*!
@brief Notified time limit.
@see AntiAddictionTimeLimit
@param AntiAddictionTimeLimit  time limit info
*/
@required
- (void)onTimeLimit:(AntiAddictionTimeLimit *)timeLimit;


@end


#endif /* AntiAddictionTimeLimitDelegate_h */
