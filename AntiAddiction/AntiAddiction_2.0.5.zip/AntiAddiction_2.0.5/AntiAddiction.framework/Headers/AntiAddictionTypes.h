//
//  AntiAddictionTypes.h
//  AntiAddictionDemo
//
//  Created by TGCenter on 2021/4/7.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#ifndef AntiAddictionTypes_h
#define AntiAddictionTypes_h

typedef const void *AntiAddictionTypeRef;

typedef const void *AntiAddictionTypeAntiAddictionClientRef;

typedef const void *AntiAddictionTypeUserRef;
typedef const void *AntiAddictionTypeRealNameResultRef;

typedef const void *AntiAddictionTypeTimeLimitRef;
typedef const void *AntiAddictionTypeLimitTipRef;

typedef void (*AntiAddictionRealNameCallback)(AntiAddictionTypeAntiAddictionClientRef *clientRef, AntiAddictionTypeUserRef *user);
typedef void (*AntiAddictionTimeLimitCallback)(AntiAddictionTypeAntiAddictionClientRef *clientRef, AntiAddictionTypeTimeLimitRef *timeLimit);


typedef const void *AntiAddictionTypeAgeTipRef;

typedef void (*AntiAddictionAgeTipShowCallback)(AntiAddictionTypeAntiAddictionClientRef *clientRef);
typedef void (*AntiAddictionAgeTipCloseCallback)(AntiAddictionTypeAntiAddictionClientRef *clientRef);


typedef const void *AntiAddictionTypeHealthGameTipRef;

typedef void (*AntiAddictionHealthGameTipShowCallback)(AntiAddictionTypeAntiAddictionClientRef *clientRef);
typedef void (*AntiAddictionHealthGameTipShowFailedCallback)(AntiAddictionTypeAntiAddictionClientRef *clientRef, int error, char *message);
typedef void (*AntiAddictionHealthGameTipCloseCallback)(AntiAddictionTypeAntiAddictionClientRef *clientRef);

#endif /* AntiAddictionTypes_h */
