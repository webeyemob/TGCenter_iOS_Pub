//
//  AntiAddictionTimeLimit.h
//  AntiAddiction
//
//  Created by tgcenter on 2021/3/19.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(int, ANTIADDICTION_TIMELIMIT_REASON) {
    ANTIADDICTION_TIMELIMIT_NO_LIMIT                        = 0,  //没有限制
    
    // 游客限制原因
    ANTIADDICTION_TIMELIMIT_TOURIST                         = 1,  // 不能体验游戏
    
    // 未成年人限制原因
    ANTIADDICTION_TIMELIMIT_CHILD_20H_21H                   = 2,  // 每日 20 时到 21 时
    ANTIADDICTION_TIMELIMIT_CHILD_HOLIDAY_1_HOUR            = 3,  // 周五、周六、周日、法定节假日每日游戏时长超过 1 小时
    ANTIADDICTION_TIMELIMIT_CHILD_NORMAL_0_HOUR             = 4,  // 其他时间不能体验游戏
};

@interface AntiAddictionLimitTip : NSObject

@property (nonatomic, strong, readonly) NSString *title;
@property (nonatomic, strong, readonly) NSString *desc;
@property (nonatomic, strong, readonly) NSString *button;
@property (nonatomic, readonly) BOOL canRealName;

- (instancetype)initWithTitle:(NSString *)title desc:(NSString *)desc button:(NSString *)button canRealName:(BOOL)canRealName;

@end

@interface AntiAddictionTimeLimit : NSObject
// 限制的原因
@property (nonatomic, readonly) ANTIADDICTION_TIMELIMIT_REASON reason;
// 距离限制的时间
// 限制时间小于一定数值时，需要提示用户
// 0 表示达到限制条件了
@property (nonatomic, readonly) long timeToLimit;
// 需要提示给用户的内容
@property (nonatomic, strong, readonly) AntiAddictionLimitTip *limitTip;

- (instancetype)initWithReason:(ANTIADDICTION_TIMELIMIT_REASON)reason;
- (instancetype)initWithReason:(ANTIADDICTION_TIMELIMIT_REASON)reason timeToLimit:(long)timeToLimit;

- (BOOL)isLimit;


@end

NS_ASSUME_NONNULL_END
