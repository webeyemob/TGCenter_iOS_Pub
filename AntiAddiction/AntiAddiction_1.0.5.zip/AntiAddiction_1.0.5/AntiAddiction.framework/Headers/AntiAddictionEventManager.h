//
//  AntiAddictionEventManager.h
//  AntiAddiction
//
//  Created by tgcenter on 2021/5/6.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AntiAddictionEventDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface AntiAddictionEventManager : NSObject

/*!
@brief Register delegate to listen realname event and timelimit event
@param delegate AntiAddictionEventDelegate that receives event
*/
+ (void)registerDelegate:(id<AntiAddictionEventDelegate>)delegate;

/*!
@brief UnRegister delegate when app exit of finish listening  realname event and timelimit event
@param delegate AntiAddictionEventDelegate that receives event
 */
+ (void)unRegisterDelegate:(id<AntiAddictionEventDelegate>)delegate;

/*!
@brief callback real name event,  App 实名认证 Custom UI 时，也可以调用此方法，这样 App 可以在一处进行数据上报
@param event AntiAddictionRealNameEvent
 */
+ (void)callbackRealNameEvent:(AntiAddictionRealNameEvent *)event;

/*!
@brief callback time limt event, App 时间限制 Custom UI 时，也可以调用此方法，这样 App 可以在一处进行数据上报
@param event AntiAddictionTimeLimitEvent
 */
+ (void)callbackTimeLimitEvent:(AntiAddictionTimeLimitEvent *)event;


@end

NS_ASSUME_NONNULL_END
