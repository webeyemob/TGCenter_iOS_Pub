//
//  AntiAddictionRealNameDelegate.h
//  AntiAddiction
//
//  Created by tgcenter on 2021/3/22.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#ifndef AntiAddictionRealNameDelegate_h
#define AntiAddictionRealNameDelegate_h
#import "AntiAddictionUser.h"

@protocol AntiAddictionRealNameDelegate<NSObject>

/*!
@brief Notified real name finish
@see AntiAddictionUser
@param AntiAddictionUser  user
*/
@required
- (void)onFinish:(AntiAddictionUser *)user;


@end



#endif /* AntiAddictionRealNameDelegate_h */
