//
//  AntiAddictionEventDelegate.h
//  AntiAddiction
//
//  Created by tgcenter on 2021/5/6.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#ifndef AntiAddictionEventDelegate_h
#define AntiAddictionEventDelegate_h
#import "AntiAddictionRealNameEvent.h"
#import "AntiAddictionTimeLimitEvent.h"

@protocol AntiAddictionEventDelegate<NSObject>

/*!
@brief Notified real name event
@param AntiAddictionRealNameEvent  event
*/
@optional
- (void)onRealName:(AntiAddictionRealNameEvent *)event;


/*!
@brief Notified time limit event
@param AntiAddictionTimeLimitEvent  event
*/
@optional
- (void)onTimeLimt:(AntiAddictionTimeLimitEvent *)event;

@end



#endif /* AntiAddictionRealNameDelegate_h */
