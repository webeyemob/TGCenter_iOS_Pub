//
//  AntiAddictionPluginUtil.h
//  AntiAddiction
//
//  Created by TGCenter on 2021/4/7.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AntiAddictionPluginUtil : NSObject

/// 将 C 语言 UTF8 编码的 byte Array 转为 NSString；如果 bytes 为 NULL，返回 nil。
+ (NSString *)AntiAddictionStringFromUTF8String:(const char *)bytes;

/// 返回 Unity 的 ViewController。
+ (UIViewController *)unityGLViewController;

/// 获取 iOS 当前的 ViewController。
+ (UIViewController *)iOSViewController;

@end

NS_ASSUME_NONNULL_END
