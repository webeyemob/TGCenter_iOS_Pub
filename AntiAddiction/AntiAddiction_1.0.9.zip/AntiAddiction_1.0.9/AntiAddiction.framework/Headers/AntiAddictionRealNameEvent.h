//
//  AntiAddictionRealNameEvent.h
//  AntiAddiction
//
//  Created by tgcenter on 2021/5/6.
//  Copyright © 2021 tgcenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AntiAddictionRealNameResult.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(int, ANTIADDICTION_REALNAME_EVENT_SOURCE) {
    ANTIADDICTION_REALNAME_EVENT_SOURCE_UNKNOWN             = -1,
    ANTIADDICTION_REALNAME_EVENT_SOURCE_SDK_UI              = 0,  // 使用 SDK UI 进行实名
    ANTIADDICTION_REALNAME_EVENT_SOURCE_CUSTOM_UI           = 1,  // 使用自定义 UI 进行实名
    ANTIADDICTION_REALNAME_EVENT_SOURCE_TIMELIMIT           = 2   // 从时间限制提示页面进入实名
};

typedef NS_ENUM(int, ANTIADDICTION_REALNAME_EVENT_ACTION) {
    ANTIADDICTION_REALNAME_EVENT_ACTION_UNKNOWN             = -1,
    ANTIADDICTION_REALNAME_EVENT_ACTION_SHOW                = 0,  // 展示实名认证页面
    ANTIADDICTION_REALNAME_EVENT_ACTION_CLOSE               = 1,  // 关闭实名认证对话框
    ANTIADDICTION_REALNAME_EVENT_ACTION_SUBMIT              = 2   // 提交实名认证
};

@interface AntiAddictionRealNameEvent : NSObject

@property (nonatomic, readonly) ANTIADDICTION_REALNAME_EVENT_SOURCE source;
@property (nonatomic, readonly) ANTIADDICTION_REALNAME_EVENT_ACTION action;
@property (nonatomic, readonly, strong, nullable) AntiAddictionRealNameResult *result;

- (instancetype)initWithSource:(ANTIADDICTION_REALNAME_EVENT_SOURCE)source action:(ANTIADDICTION_REALNAME_EVENT_ACTION)action result:(AntiAddictionRealNameResult * _Nullable)result;

@end

NS_ASSUME_NONNULL_END
