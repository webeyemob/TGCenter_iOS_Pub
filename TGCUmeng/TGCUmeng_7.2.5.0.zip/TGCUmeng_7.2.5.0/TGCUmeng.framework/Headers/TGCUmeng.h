//
//  TGCUmeng.h
//  TGCUmeng
//
//  Created by TGCenter on 2021/1/11.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TGCUmeng.
FOUNDATION_EXPORT double TGCUmengVersionNumber;

//! Project version string for TGCUmeng.
FOUNDATION_EXPORT const unsigned char TGCUmengVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TGCUmeng/PublicHeader.h>


