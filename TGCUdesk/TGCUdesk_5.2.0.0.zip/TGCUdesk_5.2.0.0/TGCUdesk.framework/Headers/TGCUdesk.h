//
//  TGCUdesk.h
//  TGCUdesk
//
//  Created by TGCenter on 2021/3/14.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TGCUdesk.
FOUNDATION_EXPORT double TGCUdeskVersionNumber;

//! Project version string for TGCUdesk.
FOUNDATION_EXPORT const unsigned char TGCUdeskVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TGCUdesk/PublicHeader.h>


#import <TGCUdesk/TGCUdeskHelper.h>
