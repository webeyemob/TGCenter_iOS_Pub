//
//  TGCUdeskHelper.h
//  TGCUdesk
//
//  Created by TGCenter on 2021/3/14.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGCUdeskHelper : NSObject

+ (void)presentUdeskInViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
