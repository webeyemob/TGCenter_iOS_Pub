//
//  Udesk.h
//  UdeskSDK
//
//  Created by Udesk on 16/6/15.
//  Copyright © 2016年 Udesk. All rights reserved.
//

#ifndef Udesk_h
#define Udesk_h

#import "UdeskManager.h"
#import "UdeskSDKManager.h"

#endif /* Udesk_h */
