//
//  UdeskGoodsModel.m
//  UdeskSDK
//
//  Created by xuchen on 2018/6/23.
//  Copyright © 2018年 Udesk. All rights reserved.
//

#import "UdeskGoodsModel.h"

@implementation UdeskGoodsParamModel

@end

@implementation UdeskGoodsModel

@end
