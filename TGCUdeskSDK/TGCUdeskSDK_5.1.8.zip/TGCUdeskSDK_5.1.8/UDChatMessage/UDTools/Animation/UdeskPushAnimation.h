//
//  UdeskPushAnimation.h
//  UdeskSDK
//
//  Created by xuchen on 2018/11/7.
//  Copyright © 2018年 Udesk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UdeskPushAnimation : NSObject<UIViewControllerAnimatedTransitioning>

@end
