//
//  UdeskWebViewController.h
//  UdeskSDK
//
//  Created by xuchen on 2019/3/4.
//  Copyright © 2019 Udesk. All rights reserved.
//

#import "UdeskBaseViewController.h"

@interface UdeskWebViewController : UdeskBaseViewController

- (instancetype)initWithURL:(NSURL *)URL;

@end
