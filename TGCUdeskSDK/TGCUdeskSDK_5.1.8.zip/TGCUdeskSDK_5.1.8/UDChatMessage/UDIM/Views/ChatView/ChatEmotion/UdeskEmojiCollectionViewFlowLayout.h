//
//  UdeskEmojiCollectionViewFlowLayout.h
//  UdeskSDK
//
//  Created by xuchen on 2018/3/26.
//  Copyright © 2018年 Udesk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UdeskEmojiCollectionViewFlowLayout : UICollectionViewFlowLayout

- (void)updatePageContent:(NSArray *)packageList;

@end
