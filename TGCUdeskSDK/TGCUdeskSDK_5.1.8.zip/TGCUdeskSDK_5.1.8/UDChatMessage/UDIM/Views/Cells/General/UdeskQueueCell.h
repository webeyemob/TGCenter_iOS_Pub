//
//  UdeskQueueCell.h
//  UdeskSDK
//
//  Created by xuchen on 2018/11/12.
//  Copyright © 2018年 Udesk. All rights reserved.
//

#import "UdeskBaseCell.h"

@interface UdeskQueueCell : UdeskBaseCell

@end
