//
//  UdeskStructCell.h
//  UdeskSDK
//
//  Created by xuchen on 2017/1/17.
//  Copyright © 2017年 xuchen. All rights reserved.
//

#import "UdeskBaseCell.h"

@interface UdeskStructCell : UdeskBaseCell

@end
