 
#import <Foundation/Foundation.h>

#define ANTI_ADDICTION_RESULT_LOGIN_SUCCESS 500 // 游戏调用 login 后用户完成登录流程
#define ANTI_ADDICTION_RESULT_SWITCH_ACCOUNT 1000 // 切换账号，当用户因防沉迷机制受限时，选择切换账号时会触发
#define ANTI_ADDICTION_RESULT_REAL_NAME_COMPLETED 1010 // 仅当游戏主动调用 openRealName 方法时，如果成功会触发
#define ANTI_ADDICTION_RESULT_REAL_NAME_CANCELLED 1015 // 仅用游戏主动调用 openRealName 方法时，如果用户取消会触发
#define ANTI_ADDICTION_RESULT_PAY_NO_LIMIT 1020 // 付费不受限，sdk检查用户付费无限制时触发
#define ANTI_ADDICTION_RESULT_PAY_LIMIT 1025 // 付费受限，付费受限触发,包括游客未实名或付费额达到限制等
#define ANTI_ADDICTION_RESULT_TIME_LIMIT 1030 // 时间受限，未成年人或游客游戏时长已达限制或受到宵禁限制无法游戏时，通知游戏
#define ANTI_ADDICTION_RESULT_OPEN_REAL_NAME 1060 // SDK请求打开游戏的实名窗口，当游戏查询支付或聊天限制时触发
#define ANTI_ADDICTION_RESULT_CHAT_NO_LIMIT 1080 // 聊天无限制，用户已通过实名，可进行聊天
#define ANTI_ADDICTION_RESULT_CHAT_LIMIT 1090 // 聊天限制，用户未通过实名，不可进行聊天
#define ANTI_ADDICTION_RESULT_AAK_WINDOW_SHOWN 2000 // 用户打开 SDK 页面，游戏暂停
#define ANTI_ADDICTION_RESULT_AAK_WINDOW_DISMISS 2500 // SDK 页面关闭，游戏恢复

#define ANTI_ADDICTION_SDK_VERSION @"1.1.5"
