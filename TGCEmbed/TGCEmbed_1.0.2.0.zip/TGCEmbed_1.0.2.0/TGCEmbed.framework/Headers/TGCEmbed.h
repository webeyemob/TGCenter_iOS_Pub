//
//  TGCEmbed.h
//  TGCEmbed
//
//  Created by TGCenter on 2021/1/11.
//  Copyright © 2021 TGCenter. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TGCEmbed.
FOUNDATION_EXPORT double TGCEmbedVersionNumber;

//! Project version string for TGCEmbed.
FOUNDATION_EXPORT const unsigned char TGCEmbedVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TGCEmbed/PublicHeader.h>


